<!-- Copilot / AI agent guidance for the Home Plate Laravel app -->

This repository is a Laravel 10 application (PHP 8.1+). The guidance below is focused, actionable, and specific to files and workflows you can inspect in this codebase.

- Project type: Laravel app skeleton customized for this project. See `composer.json` and `README.md`.
- Frontend toolchain: Vite. See `package.json` (scripts: `npm run dev` -> `vite`, `npm run build` -> `vite build`).
- Auth/API: Uses Laravel Sanctum (see `composer.json` and `app/Models/User.php`).

Quick goals for AI agents
- When making code changes, prefer small, local edits and run tests (see `phpunit.xml`).
- Preserve Laravel conventions: controllers in `app/Http/Controllers`, models in `app/Models`, routes in `routes/*`, and providers in `app/Providers`.

Essential files to inspect first
- `composer.json` — PHP package & platform requirements, autoload mapping.
- `package.json` — frontend dev commands (Vite) and dependencies.
- `routes/web.php` — primary web route(s) and middleware group (`web`).
- `app/Models/User.php` — user model, Sanctum tokens, casts, fillable/hidden fields.
- `app/Providers/*` — application service bootstrapping and registrations.
- `resources/views/welcome.blade.php` — example view and where the root route renders.

Developer workflows & commands (observed)
- Install PHP deps: use Composer (project expects `composer install`).
- Install JS deps: `npm install` or `pnpm install` (project uses Vite; package.json present).
- Dev frontend: `npm run dev` (runs Vite dev server).
- Build frontend assets: `npm run build`.
- Artisan: standard Laravel `php artisan` commands are available (e.g., `php artisan migrate`, `php artisan route:list`).
- Tests: PHPUnit is available (`vendor/bin/phpunit` or `phpunit` from vendor/bin). See `phpunit.xml`.

Patterns and conventions specific to this repo
- PSR-4 autoloading maps `App\` to `app/`. Place new classes accordingly.
- Models live under `app/Models` (e.g., `User.php`) and use `HasFactory` and `HasApiTokens` where appropriate.
- Routes are minimal; the root route renders `welcome` view. New routes should be added to `routes/web.php` or `routes/api.php` depending on intent.
- Providers are thin; `AppServiceProvider` currently contains no boot logic — add bindings here for app-wide services.

Integration points and external dependencies
- Laravel framework (see `composer.json`) — follow framework conventions for middleware, events, jobs, queues.
- Guzzle is required — used for external HTTP requests if added.
- Sanctum — used for API token authentication (check controllers for API auth behavior when present).
- Vite/laravel-vite-plugin — frontend pipeline; ensure blade templates include Vite entrypoints when adding assets.

How to make safe edits
- Run `composer install` and `npm install` before running tests locally.
- Run `php artisan key:generate` when creating an env (scripts handle this on project setup).
- When editing models, update `$fillable`, `$hidden`, and `$casts` consistently; follow `User.php` for examples.
- When adding frontend assets, update `resources/js/bootstrap.js` and blade views to include Vite hooks.

Examples from the repo to reference in PRs
- Root route: `routes/web.php` returns `view('welcome')` — use as example for adding simple pages.
- `app/Models/User.php` shows use of `HasApiTokens` and `password` casting — mirror this pattern for new auth-enabled models.

Notes and limits for agents
- Do not assume undocumented features (jobs, events, queues) exist — search `app/` for usage before adding integrations.
- No existing `.github/copilot-instructions.md` was found — this file should be the primary short guidance for AI agents.

If unsure, open these files first: `composer.json`, `package.json`, `routes/web.php`, `app/Models/User.php`, `app/Providers/AppServiceProvider.php`, and `resources/views/welcome.blade.php`.

Ask the maintainers if:
- you need conventions for route naming, API versioning, or branching/PR labels not discoverable in the repo.

End of guidance.
