 <!-- start footer section -->
<div class="mt-auto p-6 pt-0 text-center dark:text-white-dark ltr:sm:text-left rtl:sm:text-right">
    © <span id="footer-year">2022</span>. Vristo All rights reserved.
</div>
<!-- end footer section -->
