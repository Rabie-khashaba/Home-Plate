<?php $__env->startSection('title', 'Show Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel max-w-3xl mx-auto">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Admin Details</h5>
        <a href="<?php echo e(route('admins.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
            <p class="form-input bg-gray-100 dark:bg-dark"><?php echo e($admin->name); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone</label>
            <p class="form-input bg-gray-100 dark:bg-dark"><?php echo e($admin->phone); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Type</label>
            <p class="form-input bg-gray-100 dark:bg-dark"><?php echo e(ucfirst($admin->type)); ?></p>
        </div>
    </div>

    <div class="mt-8 flex gap-3">
        <a href="<?php echo e(route('admins.edit', $admin->id)); ?>" class="btn btn-primary">Edit</a>
        <form action="<?php echo e(route('admins.destroy', $admin->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\TripeAgency\home plate\home-plate\resources\views/admins/show.blade.php ENDPATH**/ ?>