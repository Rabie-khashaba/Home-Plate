<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class Vendor extends Authenticatable
{
    use HasFactory, HasApiTokens;

    protected $fillable = [
        'full_name',
        'phone',
        'email',
        'password',
        'otp_code',
        'otp_expires_at',
        'id_front',
        'id_back',
        'restaurant_info',
        'tax_card_number',
        'tax_card_image',
        'commercial_register_number',
        'commercial_register_image',
        'main_photo',
        'restaurant_name',
        'category_id',
        'city_id',
        'area_id',
        'delivery_address',
        'location',
        'kitchen_photo_1',
        'kitchen_photo_2',
        'kitchen_photo_3',
        'working_time',
        'status',
        'is_active',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'otp_expires_at' => 'datetime',
        'working_time' => 'array',
    ];

    protected $hidden = ['password'];

    public function city()
    {
        return $this->belongsTo(City::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class);
    }

    public function subcategories(): BelongsToMany
    {
        return $this->belongsToMany(Subcategory::class);
    }

    public function area()
    {
        return $this->belongsTo(Area::class);
    }

    public function items()
    {
        return $this->hasMany(Item::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    public function ratings(): HasMany
    {
        return $this->hasMany(VendorRating::class);
    }

    public function addresses(): MorphMany
    {
        return $this->morphMany(Address::class, 'addressable');
    }

    public function deviceTokens(): MorphMany
    {
        return $this->morphMany(DeviceToken::class, 'tokenable');
    }

    public function receivedNotifications(): MorphMany
    {
        return $this->morphMany(UserNotification::class, 'recipient');
    }

    public function sentNotifications(): MorphMany
    {
        return $this->morphMany(UserNotification::class, 'sender');
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }
}
