<?php $__env->startSection('title', 'Create Vendor'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Create Vendor</h5>
        <a href="<?php echo e(route('vendors.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <form method="POST" action="<?php echo e(route('vendors.store')); ?>" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <?php echo csrf_field(); ?>

        <div>
            <label>Full Name</label>
            <input type="text" name="full_name" class="form-input" value="<?php echo e(old('full_name')); ?>" required />
        </div>

        <div>
            <label>Phone Number</label>
            <input type="text" name="phone" class="form-input" value="<?php echo e(old('phone')); ?>" required />
        </div>

        <div>
            <label>Email</label>
            <input type="email" name="email" class="form-input" value="<?php echo e(old('email')); ?>" />
        </div>

        <div>
            <label>Password</label>
            <input type="password" name="password" class="form-input" required />
        </div>

        <div>
            <label>Restaurant Name</label>
            <input type="text" name="restaurant_name" class="form-input" value="<?php echo e(old('restaurant_name')); ?>" required />
        </div>

        <div>
            <label>Working Time</label>
            <input type="text" name="working_time" class="form-input" value="<?php echo e(old('working_time')); ?>" placeholder="10:00 AM - 12:00 AM" />
        </div>

        <div>
            <label>City</label>
            <select name="city_id" class="form-input" required>
                <option value="">Select City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php echo e(old('city_id') == $city->id ? 'selected' : ''); ?>><?php echo e($city->name_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label>Area</label>
            <select name="area_id" class="form-input" required>
                <option value="">Select Area</option>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>" <?php echo e(old('area_id') == $area->id ? 'selected' : ''); ?>><?php echo e($area->name_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="md:col-span-2">
            <label>Delivery Address</label>
            <textarea name="delivery_address" rows="3" class="form-input" required><?php echo e(old('delivery_address')); ?></textarea>
        </div>

        <div class="md:col-span-2">
            <label>Restaurant Info</label>
            <textarea name="restaurant_info" rows="3" class="form-input"><?php echo e(old('restaurant_info')); ?></textarea>
        </div>

        <div>
            <label>Location</label>
            <input type="text" name="location" class="form-input" value="<?php echo e(old('location')); ?>" />
        </div>

        <div>
            <label>Main Photo</label>
            <input type="file" name="main_photo" class="form-input" />
        </div>

        <div>
            <label>Upload ID Front</label>
            <input type="file" name="id_front" class="form-input" />
        </div>

        <div>
            <label>Upload ID Back</label>
            <input type="file" name="id_back" class="form-input" />
        </div>

        <div>
            <label>Kitchen Photo 1</label>
            <input type="file" name="kitchen_photo_1" class="form-input" />
        </div>

        <div>
            <label>Kitchen Photo 2</label>
            <input type="file" name="kitchen_photo_2" class="form-input" />
        </div>

        <div>
            <label>Kitchen Photo 3</label>
            <input type="file" name="kitchen_photo_3" class="form-input" />
        </div>

        <div class="md:col-span-2">
            <button type="submit" class="btn btn-primary w-full md:w-auto !mt-6">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/vendors/create.blade.php ENDPATH**/ ?>