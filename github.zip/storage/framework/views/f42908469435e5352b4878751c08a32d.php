<?php $__env->startSection('title', 'Edit Delivery'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="flex items-center justify-between mb-5">
        <h5 class="font-semibold text-lg dark:text-white-light">Edit Delivery</h5>
        <a href="<?php echo e(route('deliveries.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <form method="POST" action="<?php echo e(route('deliveries.update', $delivery->id)); ?>" enctype="multipart/form-data"
          class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label>First Name</label>
            <input type="text" name="first_name" value="<?php echo e(old('first_name', $delivery->first_name)); ?>" class="form-input" required />
        </div>

        <div>
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e(old('email', $delivery->email)); ?>" class="form-input" />
        </div>

        <div>
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo e(old('phone', $delivery->phone)); ?>" class="form-input" required />
        </div>

        <div>
            <label>City</label>
            <select name="city_id" class="form-input" required>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>" <?php echo e($delivery->city_id == $city->id ? 'selected' : ''); ?>>
                        <?php echo e($city->name_en); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label>Area</label>
            <select name="area_id" class="form-input" required>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>" <?php echo e($delivery->area_id == $area->id ? 'selected' : ''); ?>>
                        <?php echo e($area->name_en); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label>Vehicle Type</label>
            <select name="vehicle_type" class="form-input" required>
                <option value="">Select Vehicle Type</option>
                <option value="car" <?php echo e(old('vehicle_type', $delivery->vehicle_type) == 'car' ? 'selected' : ''); ?>>Car</option>
                <option value="motorcycle" <?php echo e(old('vehicle_type', $delivery->vehicle_type) == 'motorcycle' ? 'selected' : ''); ?>>Motorcycle</option>
                <option value="bicycle" <?php echo e(old('vehicle_type', $delivery->vehicle_type) == 'bicycle' ? 'selected' : ''); ?>>Bicycle</option>
            </select>
        </div>


        <div>
            <label>Status</label>
            <select name="status" class="form-input">
                <option value="pending" <?php echo e($delivery->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="approved" <?php echo e($delivery->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                <option value="rejected" <?php echo e($delivery->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
            </select>
        </div>

        <div class="flex items-center gap-2">
            <label>Active</label>
            <input type="checkbox" name="is_active" value="1" <?php echo e($delivery->is_active ? 'checked' : ''); ?> />
        </div>

        <div class="md:col-span-2 border-t pt-4 font-semibold text-gray-600">Documents</div>

        <?php $__currentLoopData = ['photo','drivers_license','national_id','vehicle_photo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label><?php echo e(ucwords(str_replace('_', ' ', $file))); ?></label>
                <input type="file" name="<?php echo e($file); ?>" class="form-input" />
                <?php if($delivery->$file): ?>
                    <img src="<?php echo e(asset('storage/app/public/'.$delivery->$file)); ?>" class="w-20 h-20 mt-2 rounded-md object-cover">
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        <div class="md:col-span-2 border-t pt-4 font-semibold text-gray-600">Vehicle License</div>

        <?php $__currentLoopData = ['front','back']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label>Vehicle License <?php echo e(ucfirst($key)); ?></label>
                <input type="file" name="vehicle_license[<?php echo e($key); ?>]" class="form-input" />
                <?php if(!empty($delivery->vehicle_license[$key])): ?>
                    <img src="<?php echo e(asset('storage/app/public/'.$delivery->vehicle_license[$key])); ?>"
                        class="w-20 h-20 mt-2 rounded-md object-cover"
                        alt="Vehicle License <?php echo e($key); ?>">
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="md:col-span-2 mt-5">
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/deliveries/edit.blade.php ENDPATH**/ ?>