<?php $__env->startSection('title', 'Edit Country'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Edit Country</h5>
        <a href="<?php echo e(route('countries.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <form class="grid grid-cols-1 md:grid-cols-2 gap-5" method="POST" action="<?php echo e(route('countries.update', $country->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="name_en">Name (English)</label>
            <input id="name_en" name="name_en" value="<?php echo e($country->name_en); ?>" type="text" class="form-input" required />
        </div>

        <div>
            <label for="name_ar">Name (Arabic)</label>
            <input id="name_ar" name="name_ar" value="<?php echo e($country->name_ar); ?>" type="text" class="form-input" required />
        </div>

        <div class="md:col-span-2">
            <button type="submit" class="btn btn-primary w-full md:w-auto !mt-6">
                Update
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\TripeAgency\home plate\home-plate\resources\views/countries/edit.blade.php ENDPATH**/ ?>