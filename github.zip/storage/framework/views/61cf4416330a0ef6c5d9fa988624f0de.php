 <!-- start footer section -->
<div class="mt-auto p-6 pt-0 text-center dark:text-white-dark ltr:sm:text-left rtl:sm:text-right">
    © <span id="footer-year">2022</span>. Homeplate All rights reserved.
</div>
<!-- end footer section -->
<?php /**PATH /home/homeplate/public_html/resources/views/partial/footer.blade.php ENDPATH**/ ?>