<?php $__env->startSection('title', 'Edit App User'); ?>

<?php $__env->startSection('content'); ?>
<div>

    <div class="pt-5">
        <div class="flex items-center justify-between mb-5">
            <h5 class="font-semibold text-lg dark:text-white-light">Edit App User</h5>
            <a href="<?php echo e(route('app_users.index')); ?>" class="btn btn-secondary">Back</a>
        </div>

        <form method="POST" action="<?php echo e(route('app_users.update', $app_user->id)); ?>" enctype="multipart/form-data"
              class="border border-[#ebedf2] dark:border-[#191e3a] rounded-md p-4 bg-white dark:bg-[#0e1726]">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <h6 class="text-lg font-bold mb-5">General Information</h6>

            <div class="flex flex-col sm:flex-row">
                <div class="ltr:sm:mr-4 rtl:sm:ml-4 w-full sm:w-2/12 mb-5 text-center">
                    <?php if($app_user->photo): ?>
                        <img src="<?php echo e(asset('storage/app/public/'.$app_user->photo)); ?>" alt="User Photo"
                             class="w-20 h-20 md:w-32 md:h-32 rounded-full object-cover mx-auto mb-3" />
                    <?php else: ?>
                        <img src="/assets/images/profile-placeholder.png" alt="No Image"
                             class="w-20 h-20 md:w-32 md:h-32 rounded-full object-cover mx-auto mb-3 opacity-60" />
                    <?php endif; ?>
                    <input type="file" name="photo" class="form-input w-full" />
                </div>

                <div class="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                        <label>Full Name</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $app_user->name)); ?>" class="form-input" required>
                    </div>

                    <div>
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo e(old('phone', $app_user->phone)); ?>" class="form-input" required>
                    </div>

                    <div>
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email', $app_user->email)); ?>" class="form-input">
                    </div>

                    <div>
                        <label>Gender</label>
                        <select name="gender" class="form-input">
                            <option value="">Select</option>
                            <option value="male" <?php echo e(old('gender', $app_user->gender) == 'male' ? 'selected' : ''); ?>>Male</option>
                            <option value="female" <?php echo e(old('gender', $app_user->gender) == 'female' ? 'selected' : ''); ?>>Female</option>
                        </select>
                    </div>

                    <div>
                        <label>Date of Birth</label>
                        <input type="date" name="dob" value="<?php echo e(old('dob', $app_user->dob ? $app_user->dob->format('Y-m-d') : '')); ?>" class="form-input">
                    </div>

                    <div>
                        <label>City</label>
                        <select name="city_id" class="form-input" required>
                            <option value="">Select City</option>
                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>" <?php echo e(old('city_id', $app_user->city_id) == $city->id ? 'selected' : ''); ?>>
                                    <?php echo e($city->name_en); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div>
                        <label>Area</label>
                        <select name="area_id" class="form-input" required>
                            <option value="">Select Area</option>
                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($area->id); ?>" <?php echo e(old('area_id', $app_user->area_id) == $area->id ? 'selected' : ''); ?>>
                                    <?php echo e($area->name_en); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="sm:col-span-2">
                        <label>Delivery Addresses</label>
                        <textarea name="delivery_addresses" rows="3" class="form-input"><?php echo e(old('delivery_addresses', $app_user->delivery_addresses)); ?></textarea>
                    </div>

                    <div>
                        <label>Location (URL)</label>
                        <input type="url" name="location" value="<?php echo e(old('location', $app_user->location)); ?>" class="form-input" required>
                    </div>

                    <div>
                        <label>Status</label><br>
                        <label class="inline-flex items-center mt-2">
                            <input type="checkbox" name="is_active" value="1" <?php echo e($app_user->is_active ? 'checked' : ''); ?> />
                            <span class="ml-2">Active</span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="flex justify-end mt-6">
                <button type="submit" class="btn btn-primary">Update User</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/app_users/edit.blade.php ENDPATH**/ ?>