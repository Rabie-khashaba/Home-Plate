<?php $__env->startSection('title', 'Admins'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">All Admins</h5>
        <a href="<?php echo e(route('admins.create')); ?>" class="btn btn-primary">Add New</a>
    </div>

    <div class="table-responsive">
        <table class="w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($admin->name); ?></td>
                    <td><?php echo e($admin->phone); ?></td>
                    <td><?php echo e(ucfirst($admin->type)); ?></td>
                    <td class="flex gap-2">
                        <a href="<?php echo e(route('admins.show', $admin->id)); ?>" class="btn btn-success">Show</a>
                        <a href="<?php echo e(route('admins.edit', $admin->id)); ?>" class="btn btn-info">Edit</a>
                        <form action="<?php echo e(route('admins.destroy', $admin->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($admins->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/admins/index.blade.php ENDPATH**/ ?>