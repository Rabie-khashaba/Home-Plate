<?php $__env->startSection('title', 'App Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">All App Users</h5>
        <a href="<?php echo e(route('app_users.create')); ?>" class="btn btn-primary">Add New</a>
    </div>

    <div class="table-responsive">
        <table class="w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Area</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->city->name_en); ?></td>
                    <td><?php echo e($user->area->name_en); ?></td>
                    <td class="flex gap-2">
                        <a href="<?php echo e(route('app_users.show', $user->id)); ?>" class="btn btn-secondary">Show</a>
                        <a href="<?php echo e(route('app_users.edit', $user->id)); ?>" class="btn btn-info">Edit</a>
                        <a href="<?php echo e(route('app_users.toggleActive', $user->id)); ?>" class="btn <?php echo e($user->is_active ? 'btn-success' : 'btn-warning'); ?>">
                            <?php echo e($user->is_active ? 'Active' : 'Inactive'); ?>

                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($users->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/app_users/index.blade.php ENDPATH**/ ?>