<?php $__env->startSection('title', 'Deliveries'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">All Deliveries</h5>
        <a href="<?php echo e(route('deliveries.create')); ?>" class="btn btn-primary">Add New</a>
    </div>

    <div class="table-responsive">
        <table class="w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Area</th>
                    <th>Vehicle Type</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($delivery->first_name); ?></td>
                    <td><?php echo e($delivery->phone); ?></td>
                    <td><?php echo e($delivery->city->name_en ?? '-'); ?></td>
                    <td><?php echo e($delivery->area->name_en ?? '-'); ?></td>
                    <td><?php echo e($delivery->vehicle_type); ?></td>
                    <td>
                        <span class="px-3 py-1 rounded-full text-white
                            <?php echo e($delivery->status == 'approved' ? 'bg-success' : ($delivery->status == 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                            <?php echo e(ucfirst($delivery->status)); ?>

                        </span>
                    </td>
                    <td class="flex gap-2">
                        <a href="<?php echo e(route('deliveries.show', $delivery->id)); ?>" class="btn btn-secondary">Show</a>
                        <a href="<?php echo e(route('deliveries.edit', $delivery->id)); ?>" class="btn btn-info">Edit</a>

                        <?php if($delivery->status === 'pending'): ?>
                            <form action="<?php echo e(route('deliveries.approve', $delivery->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success">Accept</button>
                            </form>

                            <form action="<?php echo e(route('deliveries.reject', $delivery->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Reject</button>
                            </form>
                        <?php endif; ?>

                        <form action="<?php echo e(route('deliveries.toggleStatus', $delivery->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="btn <?php echo e($delivery->is_active ? 'btn-success' : 'btn-danger'); ?>"
                                onclick="return confirm('هل أنت متأكد من تغيير الحالة؟')">
                                <?php echo e($delivery->is_active ? 'Active' : 'Inactive'); ?>

                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($deliveries->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/deliveries/index.blade.php ENDPATH**/ ?>