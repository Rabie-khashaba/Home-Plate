<?php $__env->startSection('title', 'Show Subcategory'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel max-w-3xl mx-auto">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Subcategory Details</h5>
        <a href="<?php echo e(route('subcategories.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <label class="block text-sm font-medium text-gray-600 dark:text-gray-300">Category</label>
            <p class="mt-2 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($subcategory->category->name_en); ?> / <?php echo e($subcategory->category->name_ar); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-600 dark:text-gray-300">Name (English)</label>
            <p class="mt-2 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($subcategory->name_en); ?></p>
        </div>

        <div>
            <label class="block text-sm font-medium text-gray-600 dark:text-gray-300">Name (Arabic)</label>
            <p class="mt-2 text-lg font-semibold text-gray-900 dark:text-white"><?php echo e($subcategory->name_ar); ?></p>
        </div>
    </div>

    <div class="mt-8 flex justify-end gap-3">
        <a href="<?php echo e(route('subcategories.edit', $subcategory->id)); ?>" class="btn btn-primary">Edit</a>
        <form action="<?php echo e(route('subcategories.destroy', $subcategory->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this subcategory?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\TripeAgency\home plate\home-plate\resources\views/subcategories/show.blade.php ENDPATH**/ ?>