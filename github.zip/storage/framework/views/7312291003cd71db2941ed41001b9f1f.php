<?php $__env->startSection('title', 'Create Delivery'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Create Delivery</h5>
        <a href="<?php echo e(route('deliveries.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <form method="POST" action="<?php echo e(route('deliveries.store')); ?>" enctype="multipart/form-data" class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <?php echo csrf_field(); ?>

        <div>
            <label>First Name</label>
            <input type="text" name="first_name" class="form-input" required />
        </div>

        <div>
            <label>Email (Optional)</label>
            <input type="email" name="email" class="form-input" />
        </div>

        <div>
            <label>Phone</label>
            <input type="text" name="phone" class="form-input" required />
        </div>

        <div>
            <label>Password</label>
            <input type="password" name="password" class="form-input" required />
        </div>

        <div>
            <label>City</label>
            <select name="city_id" class="form-input" required>
                <option value="">Select City</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label>Area</label>
            <select name="area_id" class="form-input" required>
                <option value="">Select Area</option>
                <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($area->id); ?>"><?php echo e($area->name_en); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div>
            <label>Vehicle Type</label>
            <select name="vehicle_type" class="form-input" required>
                <option value="">Select Vehicle Type</option>
                <option value="car">Car</option>
                <option value="motorcycle">Motorcycle</option>
                <option value="bicycle">Bicycle</option>
            </select>
        </div>

        <div class="md:col-span-2 border-t pt-4 font-semibold text-gray-600">Documents Upload</div>

        
        <?php $__currentLoopData = ['photo','drivers_license','national_id','vehicle_photo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <label><?php echo e(ucwords(str_replace('_', ' ', $file))); ?></label>
                <input type="file" name="<?php echo e($file); ?>" class="form-input" />
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div>
            <label>Vehicle License (Front)</label>
            <input type="file" name="vehicle_license[front]" class="form-input" required />
        </div>
        <div>
            <label>Vehicle License (Back)</label>
            <input type="file" name="vehicle_license[back]" class="form-input" required />
        </div>

        <div class="md:col-span-2">
            <button type="submit" class="btn btn-primary w-full md:w-auto !mt-6">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/deliveries/create.blade.php ENDPATH**/ ?>