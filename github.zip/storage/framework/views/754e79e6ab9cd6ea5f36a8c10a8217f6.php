<?php $__env->startSection('title', 'Vendors'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">All Vendors</h5>
        <a href="<?php echo e(route('vendors.create')); ?>" class="btn btn-primary">Add New</a>
    </div>

    <div class="table-responsive">
        <table class="w-full">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Restaurant</th>
                    <th>Owner</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Area</th>
                    <th>Status</th>
                    <th>Active</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($vendors->firstItem() + $key); ?></td>
                    <td><?php echo e($vendor->restaurant_name ?? '-'); ?></td>
                    <td><?php echo e($vendor->full_name ?? '-'); ?></td>
                    <td><?php echo e($vendor->phone); ?></td>
                    <td><?php echo e($vendor->city->name_en ?? '-'); ?></td>
                    <td><?php echo e($vendor->area->name_en ?? '-'); ?></td>
                    <td>
                        <span class="px-3 py-1 rounded-full text-white <?php echo e($vendor->status == 'approved' ? 'bg-success' : ($vendor->status == 'pending' ? 'bg-warning' : 'bg-danger')); ?>">
                            <?php echo e(ucfirst($vendor->status)); ?>

                        </span>
                    </td>
                    <td>
                        <span class="px-2 py-1 rounded-full text-white <?php echo e($vendor->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($vendor->is_active ? 'Active' : 'Inactive'); ?>

                        </span>
                    </td>
                    <td class="flex flex-wrap gap-2">
                        <a href="<?php echo e(route('vendors.show', $vendor->id)); ?>" class="btn btn-secondary">Show</a>
                        <a href="<?php echo e(route('vendors.edit', $vendor->id)); ?>" class="btn btn-info">Edit</a>

                        <?php if($vendor->status !== 'approved'): ?>
                            <form action="<?php echo e(route('vendors.approve', $vendor->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success">Approve</button>
                            </form>
                        <?php endif; ?>

                        <?php if($vendor->status !== 'rejected'): ?>
                            <form action="<?php echo e(route('vendors.reject', $vendor->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger">Reject</button>
                            </form>
                        <?php endif; ?>

                        <?php if($vendor->status === 'approved'): ?>
                            <form action="<?php echo e(route('vendors.toggleStatus', $vendor->id)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"
                                    class="btn <?php echo e($vendor->is_active ? 'btn-success' : 'btn-danger'); ?>"
                                    onclick="return confirm('Are you sure you want to change active status?')">
                                    <?php echo e($vendor->is_active ? 'Set Inactive' : 'Set Active'); ?>

                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4"><?php echo e($vendors->links()); ?></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/vendors/index.blade.php ENDPATH**/ ?>