<?php $__env->startSection('title', 'Show Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="panel max-w-3xl mx-auto">
    <div class="mb-5 flex items-center justify-between">
        <h5 class="text-lg font-semibold dark:text-white-light">Role Details</h5>
        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Back</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Name</label>
            <p class="form-input bg-gray-100 dark:bg-dark"><?php echo e($role->name); ?></p>
        </div>

        <div class="md:col-span-2">
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Permissions</label>
            <p class="form-input bg-gray-100 dark:bg-dark">
                <?php echo e($role->permissions->pluck('name')->join(', ')); ?>

            </p>
        </div>
    </div>

    <div class="mt-8 flex gap-3">
        <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary">Edit</a>
        <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partial.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/homeplate/public_html/resources/views/roles/show.blade.php ENDPATH**/ ?>